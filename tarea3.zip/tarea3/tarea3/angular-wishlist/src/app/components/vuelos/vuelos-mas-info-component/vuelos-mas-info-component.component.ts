import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vuelos-mas-info-component',
  templateUrl: './vuelos-mas-info-component.component.html',
  styleUrls: ['./vuelos-mas-info-component.component.css']
})
export class VuelosMasInfoComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
