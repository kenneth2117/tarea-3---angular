import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vuelos-component',
  templateUrl: './vuelos-component.component.html',
  styleUrls: ['./vuelos-component.component.css']
})
export class VuelosComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
