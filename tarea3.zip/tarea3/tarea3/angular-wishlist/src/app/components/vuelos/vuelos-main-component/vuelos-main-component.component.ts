import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vuelos-main-component',
  templateUrl: './vuelos-main-component.component.html',
  styleUrls: ['./vuelos-main-component.component.css']
})
export class VuelosMainComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
